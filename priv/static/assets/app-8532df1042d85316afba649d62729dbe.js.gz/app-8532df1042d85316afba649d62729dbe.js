(()=>{console.log("Hello world");})();
